/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import helpers.InputHelper;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import model.Restaurant;
import model.Review;
import repositories.Repository;

/**
 *
 * @author mga
 */
public class RestaurantController  {
     private final Repository repository;
    
    /**
     *constructor for the controller class that when it runs creates a repository object 
     */
        
    public RestaurantController() {
       InputHelper inputHelper = new InputHelper();
       char c = inputHelper.readCharacter("Load an already existing Customers File (Y/N)?");
        if (c == 'Y' || c == 'y') {
            String fileName = inputHelper.readString("Enter filename (no Extensions)");
            this.repository = new Repository(fileName+".json");
        }
        else {
            this.repository = new Repository();
       
        }
     }
   
    /**
     *used to manage the choices and display the menu 
     */
    public void run() {
        InputHelper inputHelper = new InputHelper();
        boolean finished = false;
        
        do {
            char choice = displayMenu();
            switch (choice) {
                case 'A': 
                    addRestaurant();
                    break;
                case 'B':  
                    addReview();
                    break;
                case 'C': 
                    listLocationRestaurantDataInNameOrder();
                    break;                    
                case 'D': 
                    listRestaurantRatings();
                    break;
                case 'Q':
                    String persist = inputHelper.readString("Name Your File (No extensions)");
                    repository.store(persist+".json");
                    finished = true;
                    
            }
        } while (!finished);
    }
    /**
     * display the menu
     * @return char value "ABCDQ"
     */
    private char displayMenu() {
        listRestaurantDataInIdOrder();
        InputHelper inputHelper = new InputHelper();
        System.out.print("\nA. Add Restaurant");
        System.out.print("\tB. Add Restaurant Review");        
        System.out.print("\tC. List Location Restaurant Data In Name Order");
        System.out.print("\tD. List Restaurant Ratings");       
        System.out.print("\tQ. Quit\n");         
        return inputHelper.readCharacter("Enter choice", "ABCDQ");
    }    
    /**
     * adds a restaurant object to the repository
     */
    private void addRestaurant() {
        InputHelper inputHelper= new InputHelper();
        System.out.format("\033[31m%s\033[0m%n", "Add Restaurant");
        System.out.format("\033[31m%s\033[0m%n", "=============="); 
        String restName = inputHelper.readString("Enter restaurant name");
        String restLocation = inputHelper.readString("Enter restaurant location");
       Restaurant r = new Restaurant(restName,restLocation);
       repository.add(r);
    }
    /**
     * add a new review object to a specified restaurant indicated with the id
     */
    private void addReview() { 
        InputHelper inputHelper= new InputHelper();
        System.out.format("\033[31m%s\033[0m%n", "Add Restaurant Review");
        System.out.format("\033[31m%s\033[0m%n", "=====================");   
        
        String restId = inputHelper.readString("Enter restaurant Id");
        int id = Integer.parseInt(restId);
        
         for(Restaurant rest:repository.getItems())
           {
           if(rest.getId()==id)
           {
               String reviewer = inputHelper.readString("Enter reviewer");
               int rating = inputHelper.readInt("Enter rating",5,1);
              
               
               Review review=new Review(reviewer, rating);
               repository.getItem(id).addReview(review);
           } 
           }
    }    
      
/**
 * the purpose of the method is to list all the object in alphabetically order given a specified location.
 * the same result can be achieved in different ways (2 implementations in this case one with a lambda expression, one with the
 * comparator method.)
    */
    private void listLocationRestaurantDataInNameOrder() {        
        System.out.format("\033[31m%s\033[0m%n", "Name Order");
        System.out.format("\033[31m%s\033[0m%n", "==========");
        InputHelper inputHelper= new InputHelper();
        String location = inputHelper.readString("Enter restaurant location");
        List<Restaurant> list = new ArrayList<Restaurant>();
        for (Restaurant rest:repository.getItems())
        {
        if(rest.getLocation().equals(location))
        {
        list.add(rest);
        }
        }  
       //Sorting Using Comparator
       //Collections.sort(list,Restaurant.restaurantNameComparator);
       //sorting using LambdaExpression
       Collections.sort(list, (Restaurant r1, Restaurant r2)-> r1.getName().compareTo(r2.getName()));
        System.out.println(list);
     }    
    /**
     * list the average between all the restaurant reviews
     */
    private void listRestaurantRatings() {
        System.out.format("\033[31m%s\033[0m%n", "Restaurant Ratings");
        System.out.format("\033[31m%s\033[0m%n", "==================");   
        
        for(Restaurant rest:repository.getItems()){
         List<Integer> sumList= new ArrayList();
           for(Review review : rest.getReviewsCollection()){
               sumList.add(review.getRating());
               }
             double sum = sumList.stream().mapToInt(Integer::intValue).sum(); 
             double average = sum / sumList.size();
             System.out.println(rest.getName() + " avarage ratings : "+ average);
        }
    }    
    /**
     * list and display the entire set of restaurant(repository) sorted by id
     */
    private void listRestaurantDataInIdOrder() {        
        System.out.format("\033[31m%s\033[0m%n", "Restaurant Id Order");
        System.out.format("\033[31m%s\033[0m%n", "===================");
        Iterator it = this.repository.getItems().iterator();
        while (it.hasNext())
        System.out.println(it.next());
    }     
}
