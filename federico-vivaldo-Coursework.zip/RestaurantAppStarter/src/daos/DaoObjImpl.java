/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daos;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import repositories.Repository;

/**
 *
 * @author feder
 */
public class DaoObjImpl implements DAOInterface{


/**
 * load a repository object from a specified object file
 * @param filename
 * @return repository
 */
    @Override
    public Repository load(String filename) {
        Repository repository = new Repository();
        try {
            FileInputStream fin= new FileInputStream(filename);
            try( ObjectInputStream ois = new ObjectInputStream(fin))
            {
                 repository=(Repository)ois.readObject(); 
            }
            } 
        catch (IOException|ClassNotFoundException ex) {
                System.out.println(ex);
            }  
      
        return repository;
    }
/**
 * store a repository object in a specified object file
 * @param filename, repository
 * @param repository 
 */
    @Override
    public void store(String filename, Repository repository) {
        
        ObjectOutputStream output = null;
        try
        {
        output = new ObjectOutputStream(new FileOutputStream(filename));
        output.writeObject(repository);
        output.close(); 
        }
        catch (IOException ex) {}
        finally 
        {
        try 
        {
        output.close();
        
        }
         catch (IOException ex) {}
        }
        
        
        
    }
}
