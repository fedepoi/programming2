/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Set;
import java.util.TreeSet;
import java.util.Comparator;
import java.util.List;

/**
 *
 * @author mga
 */
public class Restaurant implements Comparable<Restaurant>, Serializable {
    private final int id;
    private String name;
    private String location;
    private List<Review> reviewsCollection;
    
    private static int lastIdAllocated = 0;
    
    static final char EOLN='\n';       
    static final String QUOTE="\""; 

    /**
     *
     */
    public Restaurant() {
        this.id = ++lastIdAllocated;
        this.name = "TBC";
        this.location = "TBC";
        this.reviewsCollection = new ArrayList<>();        
    }

    /**
     *
     * @param name
     * @param location
     */
    public Restaurant(String name, String location) {
        this.id = ++lastIdAllocated;
        this.name = name;
        this.location = location;
        this.reviewsCollection = new ArrayList<>();
    }

    /**
     *
     * @param name
     * @param location
     * @param reviewsCollection
     */
    public Restaurant(String name, String location, List<Review> reviewsCollection) {
        this.id = ++lastIdAllocated;        
        this.name = name;
        this.location = location;
        this.reviewsCollection = reviewsCollection;
    }

    /**
     *
     * @param id
     * @param name
     * @param location
     * @param reviewsCollection
     */
    public Restaurant(int id, String name, String location, List<Review> reviewsCollection) {
        this.id = id;
        this.name = name;
        this.location = location;
        this.reviewsCollection = reviewsCollection;
        if (id > Restaurant.lastIdAllocated)
            Restaurant.lastIdAllocated = id;            
    }
    
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }  
    /**
     * @return the name
     */
    public String getName()
    {
    return name;   
    }
    /**
     * set the name
     * 
     * @param name
     */
    public void setName(String name)
    {
    this.name=name;
    }    
    /**
     * @return the location
     */
    public String getLocation()
    {
    return location;
    }
    /**
     * set the location
     * @param location
     */
    public void setLocation(String location)
    {
        this.location=location;
    }   
    /**
     * @return the reviwsCollection
     */
    public List<Review> getReviewsCollection()
    {
    return reviewsCollection;
    }
    /**
     * 
     * @param reviewsCollection
     */
    public void setReviewsCollection(List<Review> reviewsCollection)
    {
    this.reviewsCollection=reviewsCollection;
    }
    
    /**
     * Add a review to the collection
     * @param review
     */
    public void addReview(Review review)
    {
    this.getReviewsCollection().add(review);
    }
    
    
    
    /**
     * 
     * @return hashCode
     */
    @Override
    public int hashCode()
    {
     return 
             getId()*31 +
             getLocation().hashCode()*31 +
             getName().hashCode()*31 + 
             getReviewsCollection().hashCode()*31; 
        
    }
    
    
    /**
     * 
     * @param o
     * @return boolean value
     */
    @Override
    public boolean equals(Object o)
    {
    if(o instanceof Restaurant)
    {
    Restaurant r = (Restaurant)o;
    
    return r.getId()== getId() &&
            r.getLocation().equals(getLocation()) &&
            r.getName().equals(getName()) &&
            r.getReviewsCollection()== getReviewsCollection();
    }
    else 
    {
        return false;
    }
       
    }
    
    
    /**
     * used to compare the objects and sorting them in ascending or descending order(commented)
     */
     public static Comparator<Restaurant> 
             restaurantNameComparator = new Comparator<Restaurant>()
             {
             @Override 
             public int compare(Restaurant rest1,Restaurant rest2)
             {
             //String restName1= rest1.getName();
             //String restName2= rest2.getName();
             
             //ascending order
             return rest1.getName().compareTo(rest2.getName());
             
             //descending order
             //return rest2.compareTo(rest1);
             
             
             }
             };
    
  
    /**
     * 
     * @param compareRestaurant
     * @return id
     */
    @Override
    public int compareTo(Restaurant compareRestaurant) {
        int restId = ((Restaurant) compareRestaurant).getId();
        
        //ascending order
       return this.id-restId;
       //descending order
       // return id-this.restId;
 
    }
    
    /**
     *
     * @return the entire object as a String
     */
    
    @Override
    public String toString() {
        return "\nRestaurant Id: " + id + " - Name: " + name +            
                " - Location: " + location + "\nReviews: " + reviewsCollection + "\n";
    }     
    
    public String toString(char delimiter)
    {
    String str = QUOTE+ this.id + QUOTE+ delimiter + 
            QUOTE + this.name + QUOTE + delimiter +
            QUOTE + this.location + QUOTE + delimiter+ 
            QUOTE + this.reviewsCollection + QUOTE + EOLN;
    return str;      
    }

   
}
