package repositories;

import daos.DaoObjImpl;
import java.io.Serializable;
import java.util.Set;
import java.util.TreeSet;
import java.util.function.Predicate;
import model.Restaurant;


public class Repository implements  Serializable ,  RepositoryInterface {
    private Set<Restaurant> items;    
    /**
     * default constructor
     */
    public Repository() {
        this.items = new TreeSet<>();       
    }
    /**
     * constructor with one parameter
     * @param items 
     */
    public Repository(TreeSet<Restaurant> items) {        
        this.items = items;
    }
    /**
     * this constructor takes one parameter and when it runs creates a number of restaurants objects
     * @param filename 
     */
    public Repository(String filename) {
        this();
        DaoObjImpl dao = new DaoObjImpl();
        this.items = dao.load(filename).getItems();
        
        for(Restaurant rest:this.getItems())
           {
            rest=new Restaurant(rest.getName(),rest.getLocation(), rest.getReviewsCollection());
           }
    }
    /**
     * get the value of items
     * @return items
     */
    @Override
    public Set<Restaurant> getItems() {        
        return this.items;
    }
    /**
     * set the value of items
     * @param items 
     */
    @Override
    public void setItems(Set<Restaurant> items) {        
        this.items = items;
    }
    /**
     * add a restaurant object to the set
     * @param item 
     */
    @Override
    public void add(Restaurant item) 
    {
        this.items.add(item);
    }
       
    @Override
    public void remove(int id) {
        Predicate<Restaurant> predicate = e->e.getId() == id;       
        this.items.removeIf(predicate);
    }
    /**
     * get a restaurant object from the set indicated with a unique id
     * @param id
     * @return 
     */
    @Override
    public Restaurant getItem(int id) {
        for (Restaurant item:this.items) {
            if (item.getId() == id)
                return item;
        }
        return null;
    }
    /**
     * 
     * @return the entire object as a String
     */
    @Override
    public String toString() {
        return "\nItems: " + this.items;
    }    
    /**
     * store the object using a Dao object
     * @param filename 
     */
    @Override
    public void store(String filename) {       
        // create dao and execute store   
        DaoObjImpl dao = new DaoObjImpl();
        dao.store(filename, this);
    }        

   
}
